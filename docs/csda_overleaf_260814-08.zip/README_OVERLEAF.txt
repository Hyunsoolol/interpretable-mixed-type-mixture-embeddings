CSDA manuscript Overleaf package, version 260814-08

Source provenance
-----------------
main.tex is derived from manuscript_260814-08.tex.
supplement.tex is derived from supplement_260814-08.tex.
Base repository commit before packaging: f410999f.

Compilation
-----------
1. Upload this ZIP directly to a new Overleaf project.
2. Use pdfLaTeX. Overleaf will run BibTeX as required.
3. The default Main document is main.tex.
4. To compile the Supplementary Material, select supplement.tex as the
   Main document in the Overleaf project settings.

Package scope
-------------
The archive contains the two TeX sources, references.bib, all referenced
tables, and all referenced figure assets. It does not contain raw data,
simulation archives, cache files, or generated auxiliary files.

The abstract is intentionally blank in this meeting version and will be
completed after the research meeting.
