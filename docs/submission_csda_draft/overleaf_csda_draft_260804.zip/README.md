# CSDA LaTeX Draft Bundle

Initially generated from the Markdown working sources by
`scripts/build_csda_latex_draft_260713.R`, then edited and frozen at the
LaTeX stage. As of 2026-07-31, `manuscript.tex` and `supplement.tex` are the
authoritative submission text; do not regenerate them without reconciling
the later LaTeX-stage edits.

This is a review-stage flat bundle, not a frozen submission. Author names,
institutional affiliation, and BibTeX citation commands have been inserted.
Before submission, complete the corresponding-author email, any required
postal address, ORCID, CRediT, data/code-release, and publisher-required
AI-use metadata listed in
`submission_metadata_pending_260722.md`.

No-specific-funding and no-competing-interest statements have been confirmed
but are intentionally deferred from this review draft until the final
submission package is prepared.

The completed format checks and remaining release blockers are summarized in
`submission_readiness_audit_260722.md`.
Tables are automatically line-broken or scaled only when they exceed the
text width. Figures are constrained by both text width and page height.
On Overleaf, set the compiler to pdfLaTeX and use `manuscript.tex` as the
main document.

To compile the Supplement separately, change the Overleaf main document to
`supplement.tex`.
